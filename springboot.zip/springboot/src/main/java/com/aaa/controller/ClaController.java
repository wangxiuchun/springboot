package com.aaa.controller;

import com.aaa.service.ClaService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Controller
public class ClaController {
    @Resource
    private ClaService claService;
    @RequestMapping("/selectCla")
    @ResponseBody
    public List<Map> selectSla(){
        return claService.queryCla();
    }


}
