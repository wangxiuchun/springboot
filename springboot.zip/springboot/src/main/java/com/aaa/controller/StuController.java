package com.aaa.controller;

import com.aaa.entity.User;
import com.aaa.service.StuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class StuController {
    @Autowired
    private StuService stuService;

    @RequestMapping("/toShow")
    public String toShow(){
        return "show";
    }

    @RequestMapping("/selectStu")
    @ResponseBody
    public List<Map> selectStu(){// ModelAndView
        return stuService.selectStu();
//        ModelAndView mav=new ModelAndView();
//        mav.addObject("list",stuService.selectStu());
//        System.out.println(stuService.selectStu());
//        mav.setViewName("show");
//        return  mav;
    }
    @RequestMapping("/toAdd")
    public ModelAndView toAdd(){
        ModelAndView mav=new ModelAndView();
        mav.setViewName("addStu");
        return mav;
    }

    //添加
    @RequestMapping("/addStu")
    public String addStu(String sname,Integer claid){

        Map map = new HashMap();
        map.put("sname",sname);
        map.put("claid",claid);
        System.out.println("++++++"+sname);
        int a = stuService.addStu(map);
        if (a>0){
            return "forward:/selectStu";
        }
        else{
            System.out.println("+++++++++++++++++++++++++++++++");
            return "forward:/toAdd";
        }
    }

    //删除
    @RequestMapping("/deleteStu")
    public String deleteStu(int id){
        System.out.println(id+"##################");
        stuService.deleteStu(id);
        return  "forward:/selectStu";
    }

    //去修改
    @RequestMapping("/toModify")
    public ModelAndView toModify(int id){
        ModelAndView mav=new ModelAndView();
        mav.addObject("list",stuService.selectStuById(id));
        mav.setViewName("modifyStu");
        return mav;
    }

    //修改
    @RequestMapping("/modifyStu")
    @ResponseBody
    public String modifyStu(String sname,Integer stuid,Integer claid){
        Map map = new HashMap();
        map.put("sname",sname);
        map.put("stuid",stuid);
        map.put("claid",claid);
        stuService.modifyStu(map);
        return  "forward:/selectStu";
    }




}
