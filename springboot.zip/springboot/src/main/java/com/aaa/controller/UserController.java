package com.aaa.controller;

import com.aaa.entity.User;
import com.aaa.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Controller
public class UserController {
    @Resource
    private UserService userService;

    @RequestMapping("/queryUser")
    @ResponseBody
    public List<Map> queryUser(){
        return userService.queryUser();
    }

    @RequestMapping("/addUser")
    @ResponseBody
    public void addUser(User user){
        userService.addUser(user);
    }
}
