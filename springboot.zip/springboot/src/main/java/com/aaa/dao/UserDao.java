package com.aaa.dao;

import com.aaa.entity.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface UserDao {
    @Insert("insert into userinfo values (#{userid},#{userno},#{username},#{telphone},#{address})")
    public void addUser(User user);

    @Select("select * from userinfo")
    public List<Map> queryUser();
}




