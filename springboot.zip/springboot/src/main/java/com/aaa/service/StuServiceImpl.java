package com.aaa.service;

import com.aaa.dao.StuDao;
import com.aaa.dao.UserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class StuServiceImpl implements StuService {
    @Autowired
    private StuDao stuDao;
    @Override
    public List<Map> selectStu() {
        return stuDao.selectStu();
    }

    @Override
    public int addStu(Map map) {
        return stuDao.addStu(map);
    }

    @Override
    public void deleteStu(int id) {
        stuDao.deleteStu(id);
    }

    @Override
    public List<Map> selectStuById(int id) {
        return stuDao.selectStuById(id);
    }

    @Override
    public void modifyStu(Map map) {
        stuDao.modifyStu(map);
    }

}
