package com.aaa.service;

import com.aaa.dao.UserDao;
import com.aaa.entity.User;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
@Service
public class UserServiceImpl implements UserService {
    @Resource
    private UserDao userDao;

    @Override
    public void addUser(User user) {
        userDao.addUser(user);
    }

    @Override
    public List<Map> queryUser() {
        return userDao.queryUser();
    }
}
