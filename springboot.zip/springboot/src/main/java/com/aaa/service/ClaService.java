package com.aaa.service;

import java.util.List;
import java.util.Map;

public interface ClaService {
    public List<Map> queryCla();
}
