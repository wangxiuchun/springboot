package com.aaa.service;

import com.aaa.entity.User;

import java.util.List;
import java.util.Map;

public interface UserService {
    public void addUser(User user);

    public List<Map> queryUser();
}
